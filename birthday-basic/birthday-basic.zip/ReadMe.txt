账号：xieqinru
密码：0206
点击压缩完之后这个页面的index.html,就可以开始，enjoy你的生日时光^_^